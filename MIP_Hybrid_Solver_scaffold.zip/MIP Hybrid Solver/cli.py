
import argparse
import os

def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="app", required=True)

    rail = sub.add_parser("rail")
    rail.add_argument("--rail_dir", type=str, default=None)
    rail.add_argument("--out_dir", type=str, default="experiments/rail")
    rail.add_argument("--syn", type=str, default="")

    apps = sub.add_parser("apps")  # population/transport
    apps.add_argument("--config", type=str, default="")

    args = p.parse_args()

    if args.app == "rail":
        from mip_hybrid.runners.run_rail import run_rail
        synthetic = []
        if args.syn:
            for token in args.syn.split(","):
                n, m, k, dens, seed = token.split(":")
                synthetic.append((int(n), int(m), int(k), float(dens), int(seed)))
        run_rail(args.rail_dir, synthetic, args.out_dir)

    elif args.app == "apps":
        # Defer to your existing runner as-is (it likely parses its own args)
        import sys
        from mip_hybrid.runners import run_apps as _legacy_runner
        # Execute the legacy runner module's main if present; else import triggers its behavior.
        if hasattr(_legacy_runner, "main"):
            _legacy_runner.main()
        else:
            # If legacy runner uses top-level execution guard, suggest running it directly
            print("Run legacy population/transport runner directly: python -m mip_hybrid.runners.run_apps")

if __name__ == "__main__":
    main()
