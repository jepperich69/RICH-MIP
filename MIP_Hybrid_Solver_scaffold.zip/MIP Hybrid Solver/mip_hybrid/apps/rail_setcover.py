# -*- coding: utf-8 -*-
"""
Optimized edition of SETCOVER_RAIL_application_generator_A_v2.py
- Adds fast incidence indices and vectorized kernels (no pandas anywhere).
- Keeps the public CLI and behavior intact.
"""
#!/usr/bin/env python3

import argparse, time, csv, sys, math, json, datetime as dt, os
from dataclasses import dataclass
from typing import List, Tuple, Optional
import numpy as np
import heapq

# ---------- MIP backend detection ----------
_BACKEND = None
try:
    from ortools.linear_solver import pywraplp
    _BACKEND = 'ortools'
except Exception:
    try:
        import pulp
        _BACKEND = 'pulp'
    except Exception:
        _BACKEND = None

def backend_name():
    return _BACKEND

# ---------- Lightweight profiler ----------
from contextlib import contextmanager
from time import perf_counter
from collections import defaultdict

class RunProfiler:
    def __init__(self, enabled: bool = False):
        self.enabled = bool(enabled)
        self.t = defaultdict(float)         # cumulative times per label
        self.events = []                    # fine-grained timeline
        self.counters = defaultdict(int)    # simple counters
        self.meta = {}
    @contextmanager
    def section(self, name, **meta):
        if not self.enabled:
            yield
            return
        t0 = perf_counter()
        try:
            yield
        finally:
            dt = perf_counter() - t0
            self.t[name] += dt
            ev = {"label": name, "dt": dt}
            if meta:
                ev.update(meta)
            self.events.append(ev)
    def add(self, name, dt, **meta):
        if not self.enabled:
            return
        self.t[name] += dt
        ev = {"label": name, "dt": dt}
        if meta:
            ev.update(meta)
        self.events.append(ev)
    def count(self, name, inc=1):
        if not self.enabled:
            return
        self.counters[name] += inc
    def to_dict(self):
        return {
            "times": dict(self.t),
            "counters": dict(self.counters),
            "events": self.events,
            "meta": self.meta,
        }

# ---------- Instance ----------
@dataclass
class SetCoverInstance:
    A: List[List[int]]   # element -> list of sets covering it
    c: np.ndarray        # costs (m,)
    n: int               # number of elements
    m: int               # number of sets
    k: int = 1           # coverage requirement (>=k)
    # Fast incidence views (built once via build_fast_views)
    _row_ptr: Optional[np.ndarray] = None
    _col_idx: Optional[np.ndarray] = None
    _row_ids: Optional[np.ndarray] = None
    _rows_of_col: Optional[List[np.ndarray]] = None

# ----- ONE-GO SPYDER CONFIG -----
RUN_MODE = "auto"
RAIL_DEFAULT = r"C:\Users\rich\OneDrive - Danmarks Tekniske Universitet\JR\Publikationer\MIP hybrid\rail582\rail582"


# io_dump.py
import json, numpy as np

# io_dump.py
import json, os, numpy as np

def _rows_of_col_from_A(A, m):
    """
    Build rows_of_col as a list of np.array of row indices covered by each column j.
    Works from A: rows[i] -> list of columns j that cover i. Returns length-m list.
    """
    roc = [list() for _ in range(m)]
    for i, cols in enumerate(A):
        # ensure python ints, tolerate np.int64 in cols
        for j in map(int, cols):
            roc[j].append(i)
    # convert to sorted unique arrays
    return [np.array(sorted(set(rr)), dtype=int) for rr in roc]

def dump_instance_json(inst, path, controller="polish", pool=None, x_init=None,
                       time_limit=3.0, solver="highs", threads=0,
                       index_base="auto"):
    """
    Write a JSON instance for the Julia runner.

    index_base: "auto" | 0 | 1
      - "auto": write indices exactly as stored in inst.A / pool (no remapping)
      - 0 or 1: force all indices to that base (will shift if needed)
    """
    # ensure folder exists
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    n = int(inst.n); m = int(inst.m); k = int(inst.k)

    def _detect_base_rows(rows):
        # Look for the first non-empty row
        for r in rows:
            if r:
                return 0 if min(map(int, r)) == 0 else 1
        return 1

    def _shift_list(lst, from_base, to_base):
        if from_base == to_base: 
            return list(map(int, lst))
        shift = (to_base - from_base)
        return [int(x) + shift for x in lst]

    payload = {
        "n": n, "m": m, "k": k,
        "controller": controller,
        "solver": str(solver),
        "time_limit": float(time_limit),
        "threads": int(threads),
    }

    if controller == "polish":
        assert pool is not None, "pool is required for polish"
        pool = list(map(int, pool))

        # Build rows_of_col map robustly
        have_cache = (getattr(inst, "_rows_of_col", None) is not None)
        if have_cache:
            roc_list = inst._rows_of_col
        else:
            roc_list = _rows_of_col_from_A(inst.A, m)

        # Determine base if auto: infer from pool (else from rows)
        if index_base == "auto":
            base_pool = 0 if pool and min(pool) == 0 else 1
            base = base_pool
        else:
            base = int(index_base)

        # Optional remap pool/rows to desired base
        if index_base != "auto":
            # detect current base from pool or from first roc entry
            cur_base = 0 if pool and min(pool) == 0 else 1
            pool = _shift_list(pool, cur_base, base)

        rows_of_col = {}
        for j in pool:
            rr = roc_list[j]
            # rr may be np.ndarray or list; cast to Python ints and sort/unique
            if not isinstance(rr, np.ndarray):
                rr = np.array(list(map(int, rr)), dtype=int)
            rr = np.unique(rr)
            if index_base != "auto":
                # detect rr base from content
                cur_base_rr = 0 if rr.size > 0 and rr.min() == 0 else 1
                if cur_base_rr != base:
                    rr = rr + (base - cur_base_rr)
            rows_of_col[int(j)] = rr.astype(int).tolist()

        payload["pool"] = list(map(int, pool))
        payload["cost_pool"] = [float(inst.c[j]) for j in pool]
        payload["rows_of_col"] = rows_of_col

        if x_init is not None:
            # x_init may be 0/1 array for the full m; extract entries for pool
            if len(x_init) == m:
                mip_start_pool = [int(x_init[j]) for j in pool]
            else:
                # assume already aligned with pool
                mip_start_pool = [int(v) for v in x_init]
                assert len(mip_start_pool) == len(pool), "x_init length must match pool"
            payload["mip_start_pool"] = mip_start_pool

    else:
        # Full data for mip_full / greedy_round
        rows = [list(map(int, cols)) for cols in inst.A]
        # sort & dedup rows to be safe
        rows = [sorted(set(r)) for r in rows]

        if index_base == "auto":
            base = _detect_base_rows(rows)
        else:
            base = int(index_base)

        if index_base != "auto":
            # detect current base
            cur_base = _detect_base_rows(rows)
            if cur_base != base:
                rows = [_shift_list(r, cur_base, base) for r in rows]

        payload["rows"] = rows
        payload["cost"] = [float(v) for v in np.asarray(inst.c).reshape(-1)]

    with open(path, "w") as f:
        json.dump(payload, f)


def round_cover_dual(inst, x_frac: np.ndarray, y: np.ndarray):
    _ensure_rows_of_col(inst)
    n, m, k = inst.n, inst.m, inst.k
    c = inst.c

    # 1) take all columns with r_j <= 0 immediately
    r = c - np.add.reduceat(y[inst._row_ids], inst._col_idx) if hasattr(inst, "_row_ids") else \
        c - _reduced_by_scatter(inst, y)  # fallback if you don't have _row_ids/_col_idx
    x = np.zeros(m, dtype=np.int8)
    take = (r <= 0.0)
    if take.any():
        x[take] = 1

    # 2) coverage counts from current x
    cover_cnt = np.zeros(n, dtype=np.int32)
    on = np.where(x == 1)[0]
    for j in on:
        rows = inst._rows_of_col[j]
        if rows.size: cover_cnt[rows] += 1

    # 3) build lazy heap of ( -gain/cost, stamp, j ). gain = newly satisfied unit deficits if we add j
    # deficits are rows with cover_cnt < k
    deficit = (cover_cnt < k)
    if not deficit.any() and on.size > 0:
        cost = float(inst.c @ x)
        return x.astype(np.int8), cost, float(cover_cnt.min()), True

    stamp = np.zeros(m, dtype=np.int32)
    cur_stamp = 1
    heap = []

    def gain_of_col(j):
        rows = inst._rows_of_col[j]
        if rows.size == 0: return 0
        # rows that are still below k become more covered by 1 if we pick j
        return int(np.count_nonzero(deficit[rows]))

    # initialize gains only for promising columns
    # (filter out columns already on or with zero potential gain)
    for j in range(m):
        if x[j]: continue
        g = gain_of_col(j)
        if g > 0:
            heapq.heappush(heap, (-g / max(c[j], 1e-12), cur_stamp, j))
            stamp[j] = cur_stamp
    cur_stamp += 1

    # 4) greedy add until all covered >= k
    while deficit.any():
        if not heap:
            # fall back: add the cheapest column that hits any deficit row
            # (should be rare with the heap)
            best_j, best_score = -1, -1.0
            for j in range(m):
                if x[j]: continue
                g = gain_of_col(j)
                if g <= 0: continue
                sc = g / max(c[j], 1e-12)
                if sc > best_score:
                    best_score, best_j = sc, j
            if best_j == -1:
                break
            j = best_j
        else:
            sc_neg, st, j = heapq.heappop(heap)
            # lazy check: if stale, recompute and push back
            if stamp[j] != st:
                g = gain_of_col(j)
                if g > 0:
                    heapq.heappush(heap, (-g / max(c[j], 1e-12), stamp[j], j))
                continue

        # take j
        x[j] = 1
        rows = inst._rows_of_col[j]
        if rows.size:
            pre = (cover_cnt[rows] < k)
            cover_cnt[rows] += 1
            # only rows that changed from deficit→non-deficit affect gains
            changed = rows[pre & (cover_cnt[rows] >= k)]
            if changed.size:
                # for all columns touching these rows, recompute gain lazily
                touched_cols = set()
                for i in changed:
                    for jj in inst.A[i]:
                        if x[jj]: continue
                        touched_cols.add(jj)
                cur_stamp += 1
                for jj in touched_cols:
                    stamp[jj] = cur_stamp
                    g = gain_of_col(jj)
                    if g > 0:
                        heapq.heappush(heap, (-g / max(c[jj], 1e-12), cur_stamp, jj))

        deficit = (cover_cnt < k)

    feas = bool(cover_cnt.min() >= k)
    return x.astype(np.int8), float(inst.c @ x), float(cover_cnt.min()), feas

# helper when _row_ids/_col_idx aren't available (simple scatter-add)
def _reduced_by_scatter(inst, y):
    acc = np.zeros(inst.m, dtype=float)
    for i, cols in enumerate(inst.A):
        if not cols: continue
        acc[cols] += y[i]
    return acc

def resolve_rail_path(cli_val: str | None) -> str | None:
    if cli_val and os.path.isfile(cli_val):
        return cli_val
    envp = os.environ.get("RAIL_PATH", "").strip()
    if envp and os.path.isfile(envp):
        return envp
    if RAIL_DEFAULT and os.path.isfile(RAIL_DEFAULT):
        return RAIL_DEFAULT
    return None

# ---------- Fast incidence builder ----------
def build_fast_views(inst: SetCoverInstance):
    """Build CSR-like arrays + rows_of_col once and attach to instance."""
    n, m = inst.n, inst.m
    lengths = np.fromiter((len(cols) for cols in inst.A), dtype=np.int64, count=n)
    row_ptr = np.empty(n+1, dtype=np.int64)
    row_ptr[0] = 0
    np.cumsum(lengths, out=row_ptr[1:])
    nnz = int(row_ptr[-1])

    col_idx = np.empty(nnz, dtype=np.int32)
    p = 0
    for cols in inst.A:
        L = len(cols)
        if L:
            col_idx[p:p+L] = np.asarray(cols, dtype=np.int32)
            p += L

    # row index per nonzero for fast scatter/reductions
    row_ids = np.repeat(np.arange(n, dtype=np.int32), lengths)

    # rows touched by each column (reverse incidence)
    rows_of_col = [[] for _ in range(m)]
    for i, cols in enumerate(inst.A):
        for j in cols:
            rows_of_col[j].append(i)
    rows_of_col = [np.asarray(v, dtype=np.int32) if len(v) else np.empty(0, dtype=np.int32)
                   for v in rows_of_col]

    inst._row_ptr = row_ptr
    inst._col_idx = col_idx
    inst._row_ids = row_ids
    inst._rows_of_col = rows_of_col
    return inst

# --- loader of RAIL
def load_orlib_rail(path: str, k: int = 1) -> SetCoverInstance:
    import io
    with open(path, "r") as f:
        toks = []
        for line in f:
            line = line.strip()
            if not line:
                continue
            toks += line.split()
            if len(toks) >= 2:
                break
        if len(toks) < 2:
            raise ValueError("Header line with 'm n' not found.")
        m_rows, n_cols = int(toks[0]), int(toks[1])

    A = [[] for _ in range(m_rows)]
    c = np.zeros(n_cols, dtype=float)

    with open(path, "r") as f:
        header_read = False
        buf = []
        def consume_ints():
            nonlocal buf
            while True:
                if buf:
                    v = buf.pop(0)
                    return int(v)
                line = f.readline()
                if not line:
                    return None
                line = line.strip()
                if not line:
                    continue
                buf += line.split()
        _m = consume_ints(); _n = consume_ints()
        if _m != m_rows or _n != n_cols:
            raise ValueError("Header mismatch while rereading file.")
        for j in range(n_cols):
            cj = consume_ints()
            rj = consume_ints()
            if cj is None or rj is None:
                raise ValueError(f"Unexpected EOF while reading column {j+1}.")
            c[j] = float(cj)
            for _ in range(rj):
                i = consume_ints()
                if i is None:
                    raise ValueError(f"Unexpected EOF inside column {j+1}.")
                i0 = i - 1
                if not (0 <= i0 < m_rows):
                    raise ValueError(f"Row index out of range: {i} in column {j+1}.")
                A[i0].append(j)

    inst = SetCoverInstance(A=A, c=c, n=m_rows, m=n_cols, k=k)
    return build_fast_views(inst)

def make_set_cover(n: int, m: int, alpha: float = 1.8, seed: Optional[int] = None, k: int = 1) -> SetCoverInstance:
    rng = np.random.default_rng(seed if seed is not None else 2025)
    sizes = np.maximum(1, (rng.pareto(alpha, size=m) * (n / 20)).astype(int))
    S = []
    for j in range(m):
        S_j = rng.choice(n, size=min(n, sizes[j]), replace=False).tolist()
        S.append(S_j)
    c = 0.5 + rng.random(m)
    A = [[] for _ in range(n)]
    for j, S_j in enumerate(S):
        for i in S_j:
            A[i].append(j)
    for i in range(n):
        while len(A[i]) < k:
            jj = rng.integers(0, m)
            if jj not in A[i]:
                A[i].append(jj)
    inst = SetCoverInstance(A=A, c=c, n=n, m=m, k=k)
    return build_fast_views(inst)

# ---------- LP lower bound ----------
def solve_lp(inst: SetCoverInstance, timelimit: float = 60.0):
    backend = backend_name()
    t0 = time.time()
    if backend == 'ortools':
        solver = pywraplp.Solver.CreateSolver('GLOP')
        if solver is None:
            solver = pywraplp.Solver.CreateSolver('CBC')
        x = [solver.NumVar(0.0, 1.0, f"x_{j}") for j in range(inst.m)]
        for i in range(inst.n):
            ct = solver.RowConstraint(float(inst.k), solver.infinity(), f"cover_{i}")
            for j in inst.A[i]:
                ct.SetCoefficient(x[j], 1.0)
        obj = solver.Objective()
        for j in range(inst.m):
            obj.SetCoefficient(x[j], float(inst.c[j]))
        obj.SetMinimization()
        result = solver.Solve()
        t = time.time() - t0
        objv = obj.Value()
        return dict(obj=float(objv), time=float(t), status=result, backend='ortools')
    elif backend == 'pulp':
        import pulp
        prob = pulp.LpProblem("SetCoverLP", pulp.LpMinimize)
        x = [pulp.LpVariable(f"x_{j}", lowBound=0, upBound=1, cat='Continuous') for j in range(inst.m)]
        for i in range(inst.n):
            prob += pulp.lpSum([x[j] for j in inst.A[i]]) >= inst.k
        prob += pulp.lpSum(inst.c[j] * x[j] for j in range(inst.m))
        solver = pulp.PULP_CBC_CMD(msg=False, timeLimit=int(timelimit))
        prob.solve(solver)
        t = time.time() - t0
        objv = float(pulp.value(prob.objective))
        return dict(obj=objv, time=float(t), status=pulp.LpStatus[prob.status], backend='pulp')
    else:
        raise RuntimeError("No LP-capable backend found. Install OR-Tools or PuLP.")

# ---------- MIP solve ----------
def solve_mip(inst: SetCoverInstance, timelimit: float = 60.0):
    backend = backend_name()
    if backend == 'ortools':
        solver = pywraplp.Solver.CreateSolver('CBC')
        if solver is None:
            raise RuntimeError("Failed to create OR-Tools CBC solver")
        solver.SetTimeLimit(int(timelimit * 1000))
        x = [solver.IntVar(0, 1, f"x_{j}") for j in range(inst.m)]
        for i in range(inst.n):
            ct = solver.RowConstraint(float(inst.k), solver.infinity(), f"cover_{i}")
            for j in inst.A[i]:
                ct.SetCoefficient(x[j], 1.0)
        obj = solver.Objective()
        for j in range(inst.m):
            obj.SetCoefficient(x[j], float(inst.c[j]))
        obj.SetMinimization()
        t0 = time.time()
        result = solver.Solve()
        t = time.time() - t0
        xv = np.array([int(var.solution_value() > 0.5) for var in x], dtype=int)
        objv = obj.Value()
        try:
            bound = solver.Objective().BestBound()
            gap = abs(objv - bound) / max(1e-9, abs(objv))
        except Exception:
            gap = None
        return dict(x=xv, obj=float(objv), time=float(t), gap=gap, status=result, backend='ortools')
    elif backend == 'pulp':
        import pulp
        prob = pulp.LpProblem("SetCover", pulp.LpMinimize)
        x = [pulp.LpVariable(f"x_{j}", lowBound=0, upBound=1, cat='Binary') for j in range(inst.m)]
        for i in range(inst.n):
            prob += pulp.lpSum([x[j] for j in inst.A[i]]) >= inst.k
        prob += pulp.lpSum(inst.c[j] * x[j] for j in range(inst.m))
        solver = pulp.PULP_CBC_CMD(msg=False, timeLimit=int(timelimit))
        t0 = time.time()
        prob.solve(solver)
        t = time.time() - t0
        xv = np.array([int(v.value() > 0.5) for v in x], dtype=int)
        objv = float(pulp.value(prob.objective))
        return dict(x=xv, obj=objv, time=float(t), gap=None, status=pulp.LpStatus[prob.status], backend='pulp')
    else:
        raise RuntimeError("No MIP backend found. Install OR-Tools or PuLP.")

# ---------- IPF (row-wise) with dual tracking & annealing ----------
def _cov_from_x(inst: SetCoverInstance, x: np.ndarray) -> np.ndarray:
    """Row cover sums using vectorized scatter: cov[i] = sum_{j in A[i]} x[j]."""
    rp, ci, ri = inst._row_ptr, inst._col_idx, inst._row_ids
    # contribution per nonzero = x[col]
    contrib = x[ci]
    cov = np.zeros(inst.n, dtype=float)
    np.add.at(cov, ri, contrib)
    return cov

def ipf_rowwise_with_dual(inst: SetCoverInstance, tau: float, iters: int, tol: float, clip_one: bool, x0: Optional[np.ndarray] = None):
    """
    Faster row-wise KL projection using prebuilt CSR-like arrays.
    Returns x, y, smooth_obj, wall_time, lin_cost, cov_min, cov_avg.
    """
    t0 = time.time()
    q = np.exp(-inst.c / max(tau, 1e-12))
    x = q.copy() if x0 is None else x0.copy()
    y = np.zeros(inst.n, dtype=float)

    rhs = float(inst.k)
    rp, ci = inst._row_ptr, inst._col_idx

    for sweep in range(iters):
        max_violation = 0.0
        # loop rows; inner ops are vectorized on slices
        for i in range(inst.n):
            start, end = int(rp[i]), int(rp[i+1])
            if start == end:
                continue
            cols = ci[start:end]
            s = float(x[cols].sum())
            if s < rhs - tol:
                alpha = rhs / max(s, 1e-12)
                x[cols] *= alpha
                y[i] += tau * math.log(alpha)
                max_violation = max(max_violation, rhs - s)
        if clip_one:
            np.minimum(x, 1.0, out=x)
        if max_violation <= tol:
            break

    cov = _cov_from_x(inst, x)
    lin_cost = float(inst.c @ x)
    smooth_obj = lin_cost + tau * float(np.sum(x * (np.log(np.maximum(x,1e-12)) - 1.0)))
    return x, y, smooth_obj, time.time() - t0, lin_cost, float(cov.min()), float(cov.mean())

def entropy_relax_setcover_ipf_anneal(inst: SetCoverInstance, tau: float = 0.2,
                                      iters: int = 50, tol: float = 1e-3,
                                      clip_one: bool = True, tau_schedule: Optional[List[float]] = None,
                                      extra_sweeps: int = 120):
    """
    Run row-wise IPF with an optional tau schedule (coarse-to-fine).
    Warm-start between temperatures and do a final polish.
    """
    taus = tau_schedule if (tau_schedule and len(tau_schedule) > 0) else [tau]
    x = None; y = None; total_time = 0.0; lin_cost = None; smooth_obj = None; cov_min = None; cov_avg = None
    prev_t = None
    for t in taus:
        if x is None:
            x0 = None
        else:
            reweight = np.exp(-(1.0/max(t,1e-12) - 1.0/max(prev_t,1e-12)) * inst.c)
            x0 = np.clip(x * reweight, 1e-18, 1.0 if clip_one else np.inf)
        x, y, smooth_obj, dt, lin_cost, cov_min, cov_avg = ipf_rowwise_with_dual(
            inst, tau=t, iters=iters, tol=tol, clip_one=clip_one, x0=x0
        )
        total_time += dt
        prev_t = t

    sweeps = 0
    while cov_min < inst.k - tol and sweeps < extra_sweeps:
        x, y, smooth_obj, dt, lin_cost, cov_min, cov_avg = ipf_rowwise_with_dual(
            inst, tau=taus[-1], iters=10, tol=tol*0.5, clip_one=clip_one, x0=x
        )
        total_time += dt
        sweeps += 10

    return x, y, smooth_obj, total_time, lin_cost, cov_min, cov_avg

# ---------- Rounding (dual-guided + prune) ----------
def compute_reduced_costs(inst: SetCoverInstance, y: np.ndarray, prof: RunProfiler | None = None):
    t0 = perf_counter() if (prof and getattr(prof, "enabled", False)) else None
    acc = np.zeros(inst.m, dtype=float)
    np.add.at(acc, inst._col_idx, y[inst._row_ids])
    out = inst.c - acc
    if t0 is not None:
        prof.add('reduced_costs', perf_counter() - t0)
    return out

def round_cover_dual(inst: SetCoverInstance, x_frac: np.ndarray, y: np.ndarray):
    n, m, k = inst.n, inst.m, int(inst.k)
    S = inst._rows_of_col
    r = compute_reduced_costs(inst, y)

    x_int = np.zeros(m, dtype=int)
    cover_cnt = np.zeros(n, dtype=int)
    # take all non-positive reduced cost columns
    nz = np.where(r <= 1e-12)[0]
    if nz.size:
        x_int[nz] = 1
        for j in nz:
            rows = S[j]
            if rows.size:
                cover_cnt[rows] += 1

    def gain_of(j):
        if x_int[j] == 1: return 0
        rows = S[j]
        if rows.size == 0: return 0
        deficit = (cover_cnt[rows] < k).sum()
        return int(deficit)

    safety = 0
    while np.any(cover_cnt < k) and safety < 5*m:
        best, best_ratio = -1, float('inf')
        # consider only columns that touch some under-covered row
        deficit_rows = np.where(cover_cnt < k)[0]
        cand = set()
        for i in deficit_rows:
            for j in inst.A[i]:
                if x_int[j] == 0:
                    cand.add(j)
        for j in cand:
            g = gain_of(j)
            if g > 0:
                eff_cost = max(1e-12, r[j])
                ratio = eff_cost / g
                if ratio < best_ratio:
                    best_ratio = ratio; best = j
        if best == -1:
            i0 = int(np.argmin(cover_cnt))
            cand2 = [j for j in inst.A[i0] if x_int[j]==0]
            if not cand2: break
            best = min(cand2, key=lambda jj: r[jj])
        x_int[best] = 1
        rows = S[best]
        if rows.size:
            need = cover_cnt[rows] < k
            cover_cnt[rows[need]] += 1
        safety += 1

    # prune
    improved = True
    on_cols = np.where(x_int==1)[0]
    while improved:
        improved = False
        for j in on_cols:
            if x_int[j] == 0: 
                continue
            rows = S[j]
            if rows.size == 0: 
                x_int[j] = 0
                continue
            # check if removing j violates any row
            if np.any(cover_cnt[rows] - 1 < k):
                continue
            x_int[j] = 0
            cover_cnt[rows] -= 1
            improved = True

    cov_min = float(cover_cnt.min()) if cover_cnt.size else 0.0
    feasible = bool(cov_min >= k)
    cost = float(inst.c @ x_int)
    return x_int, cost, cov_min, feasible

def round_cover_greedy(inst, x_frac: np.ndarray):
    _ensure_rows_of_col(inst)
    n, m, k = inst.n, inst.m, inst.k
    c = inst.c

    # initial ranking by cost/coverage weight from fractional solution
    # (use -x_frac/c as a proxy; avoids loops)
    score = x_frac / np.maximum(c, 1e-12)
    order = np.argsort(-score)  # best first

    x = np.zeros(m, dtype=np.int8)
    cover_cnt = np.zeros(n, dtype=np.int32)

    # 1) add columns until all rows reach k
    for j in order:
        if np.all(cover_cnt >= k):
            break
        rows = inst._rows_of_col[j]
        if rows.size == 0:
            continue
        # marginal gain test: does j hit any deficit row?
        if np.any(cover_cnt[rows] < k):
            x[j] = 1
            cover_cnt[rows] += 1

    feas = bool(cover_cnt.min() >= k)
    if not feas:
        # 2) fast repair: add cheapest columns that hit remaining deficits
        deficit_rows = np.where(cover_cnt < k)[0]
        needed = k - cover_cnt[deficit_rows]
        # simple loop over deficit rows, but each step uses vector ops
        for i in deficit_rows:
            need = k - cover_cnt[i]
            if need <= 0: continue
            # pick 'need' cheapest unused columns covering row i
            cands = [j for j in inst.A[i] if x[j] == 0]
            if cands:
                jj = np.argsort(c[cands])[:int(need)]
                for idx in jj:
                    j = cands[int(idx)]
                    x[j] = 1
                    rows = inst._rows_of_col[j]
                    if rows.size: cover_cnt[rows] += 1
        feas = bool(cover_cnt.min() >= k)

    return x.astype(np.int8), float(inst.c @ x), float(cover_cnt.min()), feas

def randomized_rounding_trials(inst, x_frac, trials: int = 20, thr_max: float = 0.6, rng=None):
    _ensure_rows_of_col(inst)
    n, m, k = inst.n, inst.m, inst.k
    c = inst.c
    if rng is None:
        rng = np.random.default_rng()

    # precompute cumulative cost ranking for repairs
    cost_order = np.argsort(c)

    best_x = None
    best_cost = float('inf')
    best_cov = 0
    best_feas = False

    # batch-generate masks: U[0,1) per col per trial, threshold by scaled x_frac
    p = np.clip(x_frac / max(x_frac.max(), 1e-9), 0.0, 1.0) * thr_max
    U = rng.random((trials, m))
    picks = (U < p)  # (trials, m) boolean

    for t in range(trials):
        sel = picks[t]
        x = sel.astype(np.int8)
        cover_cnt = np.zeros(n, dtype=np.int32)
        on = np.where(x == 1)[0]
        for j in on:
            rows = inst._rows_of_col[j]
            if rows.size: cover_cnt[rows] += 1

        # quick repair if any deficits
        while True:
            deficit_rows = np.where(cover_cnt < k)[0]
            if deficit_rows.size == 0: break
            # pick cheapest column that hits any deficit row (vector-friendly)
            # build a small candidate set: union of columns covering first 64 deficit rows
            cand_cols = set()
            for i in deficit_rows[:64]:
                for j in inst.A[i]:
                    if x[j] == 0:
                        cand_cols.add(j)
            if not cand_cols:
                break
            # choose best by (gain/cost)
            best_j, best_sc = -1, -1.0
            for j in cand_cols:
                rows = inst._rows_of_col[j]
                if rows.size == 0: continue
                g = int(np.count_nonzero(cover_cnt[rows] < k))
                if g <= 0: continue
                sc = g / max(c[j], 1e-12)
                if sc > best_sc:
                    best_sc, best_j = sc, j
            if best_j == -1:
                break
            x[best_j] = 1
            rows = inst._rows_of_col[best_j]
            if rows.size: cover_cnt[rows] += 1

        feas = bool(cover_cnt.min() >= k)
        cost = float(inst.c @ x)
        if (feas and cost < best_cost) or (not best_feas and feas) or (best_x is None):
            best_x, best_cost, best_cov, best_feas = x.copy(), cost, float(cover_cnt.min()), feas

    if best_x is None:
        return np.zeros(m, dtype=np.int8), float('inf'), 0.0, False
    return best_x.astype(np.int8), best_cost, best_cov, best_feas

def local_improve_drop_and_fix(inst, x_int, passes: int = 2, rng=None):
    _ensure_rows_of_col(inst)
    n, m, k = inst.n, inst.m, inst.k
    c = inst.c
    if rng is None:
        rng = np.random.default_rng()

    x = x_int.astype(np.int8).copy()
    # coverage counts once
    cover_cnt = np.zeros(n, dtype=np.int32)
    on = np.where(x == 1)[0]
    for j in on:
        rows = inst._rows_of_col[j]
        if rows.size: cover_cnt[rows] += 1

    for _ in range(max(1, passes)):
        order = on.copy()
        rng.shuffle(order)  # random order
        kept = []
        for j in order:
            rows = inst._rows_of_col[j]
            if rows.size == 0:
                x[j] = 0
                continue
            # if any row would drop below k -> keep j
            if np.any(cover_cnt[rows] <= k):
                kept.append(j)
                continue
            # safe to drop
            x[j] = 0
            cover_cnt[rows] -= 1
        on = np.array(kept, dtype=int)

    feas = bool(cover_cnt.min() >= k)
    return x.astype(np.int8), float(inst.c @ x), float(cover_cnt.min()), feas


# ---------- Restricted MIP polish ----------
def polish_restricted_mip(inst: SetCoverInstance, x_init: np.ndarray, r: np.ndarray,
                          timelimit=0.5, pool_frac=0.25,
                          prof: 'RunProfiler|None' = None):
    from ortools.linear_solver import pywraplp
    import time
    m = inst.m

    pool = set(np.where(x_init == 1)[0])
    k_pool = min(m, max(len(pool), int(pool_frac * m)))
    cand_by_r = np.argsort(r)[:k_pool]
    pool.update(cand_by_r.tolist())
    pool = sorted(pool)

    solver = pywraplp.Solver.CreateSolver('CBC')
    if solver is None:
        return x_init.copy(), float(inst.c @ x_init), False, 0.0

    try:
        solver.EnableOutput(False)
    except Exception:
        pass
    solver.SetTimeLimit(int(1000 * timelimit))

    x = {j: solver.IntVar(0, 1, f"x_{j}") for j in pool}

    for i in range(inst.n):
        ct = solver.RowConstraint(float(inst.k), solver.infinity(), "")
        for j in inst.A[i]:
            v = x.get(j)
            if v is not None:
                ct.SetCoefficient(v, 1.0)

    obj = solver.Objective()
    for j in pool:
        obj.SetCoefficient(x[j], float(inst.c[j]))
    obj.SetMinimization()

    try:
        solver.SetHint([x[j] for j in pool], [float(x_init[j]) for j in pool])
    except Exception:
        pass

    t0 = time.time()
    status = solver.Solve()
    t = time.time() - t0
    if prof and getattr(prof, "enabled", False):
        prof.add('polish_mip', t)

    if status not in (pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE):
        return x_init.copy(), float(inst.c @ x_init), False, t

    x_new = np.zeros(m, dtype=int)
    for j in pool:
        if x[j].solution_value() > 0.5:
            x_new[j] = 1

    # quick feasibility check
    cover = np.zeros(inst.n, dtype=int)
    for i in range(inst.n):
        cover[i] = int(x_new[inst.A[i]].sum())
    feasible = bool(cover.min() >= inst.k)
    cost = float(inst.c @ x_new)
    return x_new, cost, feasible, t

# ---------- Benchmark harness ----------
def run_family(args):
    import numpy as np
    from time import perf_counter as _pc

    # --------- local stage timers (seconds) ---------
    _T = {
        "lp_solve": 0.0,
        "mip_solve": 0.0,
        "relax_total": 0.0,
        "round_rr_trials": 0.0,
        "round_main": 0.0,
        "improve_local": 0.0,
        "polish_mip": 0.0,
        "reduced_costs": 0.0,
    }
    _tall0 = _pc()  # global wall-time start

    if getattr(args, "seed", None) is not None:
        np.random.seed(args.seed)
        import random
        random.seed(args.seed)

    def _fmt(v):
        try:
            return f"{v:.3f}" if (v is not None and np.isfinite(v)) else "NA"
        except Exception:
            return "NA"

    # ---------- Load instance ----------
    rail_path = getattr(args, "rail_path", None)
    if not rail_path:
        return _run_family_synthetic(args)
    
    try:
        inst = load_orlib_rail(rail_path, k=getattr(args, "kcover", 1))
    except Exception as e:
        print(f"[rail] Failed to load '{rail_path}': {e}")
        return

    # --- seed random generators for reproducibility ---
    if getattr(args, "seed", None) is not None:
        import random, numpy as np
        random.seed(args.seed)
        np.random.seed(args.seed)
        
        # build rows-per-column index once
        _ensure_rows_of_col(inst)

    print(f"[rail] Loaded: n={inst.n} rows, m={inst.m} cols, k={inst.k}")

    # ---------- LP lower bound (optional) ----------
    lp_res = None
    if bool(getattr(args, "lp_lower_bound", False)):
        try:
            t0 = _pc()
            lp_res = solve_lp(inst, timelimit=getattr(args, "timelimit", None))
            _T["lp_solve"] += (_pc() - t0)
            if isinstance(lp_res, dict) and "obj" in lp_res:
                print(f"[rail] LP lower bound = {lp_res['obj']:.3f} (t={lp_res.get('time', float('nan')):.2f}s)")
        except Exception as e:
            print(f"[rail] LP failed: {e}")

    # ---------- MIP solve (if requested) ----------
    mip_res = None
    ctrl = getattr(args, "controller", "both")
    if ctrl in ("mip", "both", "onego"):
        try:
            t0 = _pc()
            mip_res = solve_mip(inst, timelimit=getattr(args, "timelimit", None))
            _T["mip_solve"] += (_pc() - t0)
            if isinstance(mip_res, dict) and "obj" in mip_res:
                print(f"[rail] MIP obj={mip_res['obj']:.3f}, "
                      f"gap={mip_res.get('gap', float('nan')):.4f}, "
                      f"t={mip_res.get('time', float('nan')):.2f}s")
        except Exception as e:
            print(f"[rail] MIP failed: {e}")

    # If pure MIP, stop here
    if ctrl not in ("hybrid", "both", "onego"):
        return

    # ---------- Tau schedule (optional) ----------
    tau_sched = None
    if getattr(args, "tau_schedule", None):
        try:
            tau_sched = [float(t) for t in args.tau_schedule.split(",")]
        except Exception:
            print("[rail] Could not parse --tau_schedule, ignoring.")

    # ---------- Relaxation (entropy/IPF) ----------
    try:
        t0 = _pc()
        x_frac, y, obj_relax, t_relax, lin_relax, cov_min, cov_avg = entropy_relax_setcover_ipf_anneal(
            inst,
            tau=getattr(args, "tau", 0.2),
            iters=getattr(args, "iters", 50),
            tol=getattr(args, "tol", 1e-3),
            clip_one=(inst.k == 1),
            tau_schedule=tau_sched,
            extra_sweeps=120
        )
        # prefer function-reported t_relax if provided
        _T["relax_total"] += (float(t_relax) if (t_relax is not None) else (_pc() - t0))
    except Exception as e:
        print(f"[rail] Relaxation failed: {e}")
        return

    # ---------- Rounding & Improvement ----------
    try:
        x_int, obj_hyb, cov_min_int, feasible_int = None, float('inf'), 0.0, False

        # randomized rounding trials (optional)
        if getattr(args, "rr_trials", 0) > 0:
            t0 = _pc()
            xi, ci, covi, feasi = randomized_rounding_trials(
                inst, x_frac,
                trials=getattr(args, "rr_trials", 20),
                thr_max=getattr(args, "rr_thr_max", 0.6)
            )
            _T["round_rr_trials"] += (_pc() - t0)
            if feasi and ci < obj_hyb:
                x_int, obj_hyb, cov_min_int, feasible_int = xi, ci, covi, feasi

        # main rounding (dual or greedy)
        if not feasible_int:
            t0 = _pc()
            if getattr(args, "rounding", "dual") == "dual":
                xi, ci, covi, feasi = round_cover_dual(inst, x_frac, y)
            else:
                xi, ci, covi, feasi = round_cover_greedy(inst, x_frac)
            _T["round_main"] += (_pc() - t0)
            if feasi and ci < obj_hyb:
                x_int, obj_hyb, cov_min_int, feasible_int = xi, ci, covi, feasi

        # local improvement
        if feasible_int and getattr(args, "improve_passes", 0) > 0:
            t0 = _pc()
            xi, ci, covi, feasi = local_improve_drop_and_fix(
                inst, x_int, passes=getattr(args, "improve_passes", 2)
            )
            _T["improve_local"] += (_pc() - t0)
            if feasi and ci < obj_hyb:
                x_int, obj_hyb, cov_min_int, feasible_int = xi, ci, covi, feasi

    except Exception as e:
        print(f"[rail] Rounding/improvement failed: {e}")
        feasible_int = False

    # Objective before polish (post rounding/improve)
    obj_hyb_pre = obj_hyb if (obj_hyb is not None and np.isfinite(obj_hyb)) else None

    # ---------- Polish (restricted MIP) ----------
    hyb_polished = False
    try:
        if feasible_int and (y is not None) and backend_name() == "ortools":
            # reduced costs (time here for visibility)
            t0 = _pc()
            r = compute_reduced_costs(inst, y)
            _T["reduced_costs"] += (_pc() - t0)

            t0 = _pc()
            x_pol, cost_pol, feas_pol, t_pol = polish_restricted_mip(
                inst, x_init=x_int, r=r,
                timelimit=getattr(args, "polish_time", 1.0),
                pool_frac=getattr(args, "polish_pool", 0.5)
            )
            _T["polish_mip"] += (_pc() - t0)

            if feas_pol and cost_pol < obj_hyb:
                x_int, obj_hyb = x_pol, cost_pol
                hyb_polished = True
    except Exception as e:
        print(f"[rail] Polish failed (continuing): {e}")

    obj_hyb_post = obj_hyb if (obj_hyb is not None and np.isfinite(obj_hyb)) else obj_hyb_pre

    # ---------- Rich summary (objectives + wall time + per-stage split) ----------
    T_total = _pc() - _tall0
    sum_stages = sum(_T.values())

    hyb_line = (f"[rail] HYB int={_fmt(obj_hyb_post)}"
                f"{' +polish' if hyb_polished else ''} "
                f"(feas={'OK' if feasible_int else 'INFEAS'}), "
                f"relax_lin={_fmt(lin_relax)}, "
                f"cov_min_frac={_fmt(cov_min)}, "
                f"cov_min_int={_fmt(cov_min_int)}, "
                f"T={T_total:.2f}s (relax={_fmt(t_relax)}s, Σstages={sum_stages:.2f}s)"
                f" | objs: relax={_fmt(obj_relax)}, round={_fmt(obj_hyb_pre)}, polish={_fmt(obj_hyb_post)}")

    # add LP/MIP refs and hybrid gap vs MIP
    if isinstance(lp_res, dict) and ('obj' in lp_res):
        hyb_line += f", lp={_fmt(lp_res['obj'])}"
    if isinstance(mip_res, dict) and ('obj' in mip_res):
        hyb_line += f", mip={_fmt(mip_res['obj'])}"
        if feasible_int and (obj_hyb_post is not None) and np.isfinite(obj_hyb_post):
            pct_gap = (obj_hyb_post - mip_res['obj']) / max(1e-9, abs(mip_res['obj']))
            hyb_line += f", gap%={100.0*pct_gap:.2f}"

    # per-stage times (always shown)
    hyb_line += (f" | times(s): relax={_T['relax_total']:.2f}, "
                 f"round_main={_T['round_main']:.2f}, "
                 f"round_rr={_T['round_rr_trials']:.2f}, "
                 f"improve={_T['improve_local']:.2f}, "
                 f"polish={_T['polish_mip']:.2f}, "
                 f"mip={_T['mip_solve']:.2f}, "
                 f"lp={_T['lp_solve']:.2f}, "
                 f"redcost={_T['reduced_costs']:.2f})")

    print(hyb_line)

def run_family_synthetic(scales, trials=3, tau=0.2, timelimit=60.0, seed=2025, args_k=1,
               controller='both', iters=50, tol=1e-3,
               relax_engine='ipf', tau_schedule=None, rounding='dual',
               lp_lower_bound: bool = True):
    rows = []
    for (n, m) in scales:
        for rep in range(trials):
            seed_used = int(seed + 1000*rep + n + m)
            inst = make_set_cover(n, m, seed=seed_used, k=args_k)

            lp = solve_lp(inst, timelimit=timelimit) if lp_lower_bound else None
            mip = solve_mip(inst, timelimit=timelimit) if controller in ('mip','both') else None

            if controller in ('hybrid','both'):
                taus = [float(t) for t in tau_schedule.split(",")] if tau_schedule else None
                x_frac, y, obj_relax, t_relax, lin_relax, cov_min, cov_avg = entropy_relax_setcover_ipf_anneal(
                    inst, tau=tau, iters=iters, tol=tol,
                    clip_one=(inst.k == 1),
                    tau_schedule=taus, extra_sweeps=120
                )
                if rounding == 'dual':
                    x_int, obj_hyb, cov_min_int, feasible_int = round_cover_dual(inst, x_frac, y)
                else:
                    x_int, obj_hyb, cov_min_int, feasible_int = round_cover_greedy(inst, x_frac)
                t_hyb_total = t_relax

                hyb_polished = False
                if y is not None and backend_name() == 'ortools':
                    r = compute_reduced_costs(inst, y)
                    x_pol, cost_pol, feas_pol, t_pol = polish_restricted_mip(
                        inst, x_init=x_int, r=r, timelimit=0.5, pool_frac=0.25
                    )
                    if feas_pol and cost_pol < obj_hyb:
                        x_int, obj_hyb = x_pol, cost_pol
                        cover_cnt = np.zeros(inst.n, dtype=int)
                        for i in range(inst.n):
                            cover_cnt[i] = sum(x_int[j] for j in inst.A[i])
                        cov_min_int = float(cover_cnt.min())
                        feasible_int = bool(cov_min_int >= inst.k)
                        t_hyb_total += t_pol
                        hyb_polished = True
            else:
                x_frac = y = obj_relax = t_relax = lin_relax = cov_min = cov_avg = None
                x_int = obj_hyb = cov_min_int = feasible_int = None
                t_hyb_total = None
                hyb_polished = False

            pct_gap = ((obj_hyb - mip['obj']) / max(1e-9, mip['obj'])) \
                if (mip is not None and mip.get('gap') is not None and abs(mip.get('gap')) < 1e-9
                    and obj_hyb is not None and feasible_int) else None
            lp_gap_hyb = ((obj_hyb - lp['obj']) / max(1e-9, lp['obj'])) if (lp_lower_bound and lp is not None and obj_hyb is not None and feasible_int) else None
            lp_gap_mip = ((mip['obj'] - lp['obj']) / max(1e-9, lp['obj'])) if (lp_lower_bound and lp is not None and mip is not None) else None

            rows.append({
                "family":"setcover",
                "n":n, "m":m, "tau":tau, "trial":rep+1,
                "k": args_k,
                "seed_used": seed_used,
                "controller": controller,
                "relax_engine": relax_engine,
                "rounding": rounding,
                "tau_schedule": tau_schedule,
                "lp_backend": (lp.get('backend') if (lp_lower_bound and lp is not None) else None),
                "lp_obj": (lp['obj'] if (lp_lower_bound and lp is not None) else None),
                "lp_time": (lp['time'] if (lp_lower_bound and lp is not None) else None),
                "mip_backend": (mip.get('backend') if mip is not None else None),
                "mip_obj": (mip['obj'] if mip is not None else None),
                "mip_gap": (mip.get('gap') if mip is not None else None),
                "mip_time": (mip['time'] if mip is not None else None),
                "mip_status": (mip['status'] if mip is not None else None),
                "hyb_relax_obj": obj_relax,
                "hyb_relax_lin_cost": lin_relax,
                "hyb_relax_cov_min": cov_min,
                "hyb_relax_cov_avg": cov_avg,
                "hyb_relax_time": t_relax,
                "hyb_int_obj": obj_hyb,
                "hyb_int_cov_min": cov_min_int,
                "hyb_int_feasible": feasible_int,
                "hyb_total_time": t_hyb_total,
                "hyb_pct_gap_vs_mip": pct_gap,
                "hyb_vs_lp_pct_gap": lp_gap_hyb,
                "mip_vs_lp_pct_gap": lp_gap_mip,
                "hyb_polished": hyb_polished,
                "hyb_polish_time": (t_hyb_total - t_relax) if (t_hyb_total and hyb_polished) else 0.0,
            })

            if controller in ('both','mip') and controller in ('both','hybrid') and mip is not None and obj_hyb is not None:
                feas = "OK" if feasible_int else "INFEAS"
                gap_str = f"{(pct_gap*100):.2f}%" if pct_gap is not None else "NA"
                pol = " +polish" if hyb_polished else ""
                print(f"[n={n}, m={m}, rep={rep+1}]  "
                      f"MIP obj={mip['obj']:.3f}, gap={(mip['gap'] if mip.get('gap') is not None else float('nan')):.3f}, t={mip['time']:.2f}s  |  "
                      f"HYB({relax_engine},{rounding}) int={obj_hyb:.3f}{pol} ({feas}, gap%={gap_str}), "
                      f"lin-relax={(lin_relax if lin_relax is not None else float('nan')):.3f}, cov_min_frac={(cov_min if cov_min is not None else float('nan')):.2f}, "
                      f"cov_min_int={(cov_min_int if cov_min_int is not None else float('nan')):.2f}, t={(t_hyb_total if t_hyb_total is not None else float('nan')):.2f}s")
            elif controller == 'mip' and mip is not None:
                print(f"[n={n}, m={m}, rep={rep+1}]  MIP obj={mip['obj']:.3f}, gap={(mip['gap'] if mip.get('gap') is not None else float('nan')):.3f}, t={mip['time']:.2f}s")
            elif controller == 'hybrid' and obj_hyb is not None:
                feas = "OK" if feasible_int else "INFEAS"
                pol = " +polish" if hyb_polished else ""
                print(f"[n={n}, m={m}, rep={rep+1}]  HYB({relax_engine},{rounding}) int={obj_hyb:.3f}{pol} ({feas}), "
                      f"lin-relax={(lin_relax if lin_relax is not None else float('nan')):.3f}, cov_min_frac={(cov_min if cov_min is not None else float('nan')):.2f}, "
                      f"cov_min_int={(cov_min_int if cov_min_int is not None else float('nan')):.2f}, t={(t_hyb_total if t_hyb_total is not None else float('nan')):.2f}s")

    return rows

def write_csv(rows, out_path):
    if not rows:
        return
    keys = list(rows[0].keys())
    with open(out_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _ensure_rows_of_col(inst):
    """Build inst._rows_of_col (rows per column) once, cached on the instance."""
    if getattr(inst, "_rows_of_col", None) is not None:
        return

    rows_of_col = [[] for _ in range(inst.m)]
    for i, cols in enumerate(inst.A):
        for j in cols:
            rows_of_col[j].append(i)

    inst._rows_of_col = [
        np.asarray(r, dtype=np.int32) if r else np.empty(0, np.int32)
        for r in rows_of_col
    ]


def parse_scales(s: str):
    out = []
    for token in s.split(","):
        n,m = token.split("x")
        out.append((int(n), int(m)))
    return out

def main():
    p = argparse.ArgumentParser(description="Set Cover benchmark: MIP vs Entropy Hybrid (optimized+profiled)")
    # --- synthetic experiment args ---
    p.add_argument("--scales", type=str, default="400x200,800x400,1600x800")
    p.add_argument("--trials", type=int, default=2)
    p.add_argument("--tau", type=float, default=0.1)
    p.add_argument("--tau_schedule", type=str, default=None)
    p.add_argument("--timelimit", type=float, default=60.0)
    p.add_argument("--seed", type=int, default=2025)
    p.add_argument("--kcover", type=int, default=1)
    p.add_argument("--controller", type=str, default="both", choices=["mip","hybrid","both","onego"])
    p.add_argument("--iters", type=int, default=200)
    p.add_argument("--tol", type=float, default=1e-3)
    p.add_argument("--rounding", type=str, default="dual", choices=["dual","greedy"])
    p.add_argument("--lp_lower_bound", action="store_true")
    p.add_argument("--out", type=str, default=None)
#    p.add_argument("--seed", type=int, default=2025,
#               help="Random seed for reproducibility")

    # --- profiling ---
    p.add_argument("--profile", action="store_true", help="Enable fine-grained timing")
    p.add_argument("--profile_out", type=str, default=None, help="Write profile JSON")

    # --- RAIL args ---
    p.add_argument("--rail_path", type=str, default=None)
    p.add_argument("--rr_trials", type=int, default=1)
    p.add_argument("--rr_thr_max", type=float, default=0.8)
    p.add_argument("--improve_passes", type=int, default=1)
    p.add_argument("--polish_time", type=float, default=3.0)
    p.add_argument("--polish_pool", type=float, default=0.25)
    args = p.parse_args()
    # auto-enable profiling in onego
    if args.controller == "onego":
        args.profile = True
        if not args.profile_out:
            # default profile dump name (rail/synthetic branches each write JSON)
            ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            args.profile_out = f"profile_{ts}.json"

    
    if args.kcover >= 2 and (args.tau_schedule is None):
        args.tau_schedule = "0.5,0.2,0.1,0.05,0.02"
    if args.kcover >= 2 and args.tol == 1e-3:
        args.tol = 5e-4

    mode = RUN_MODE.lower()
    rail_auto = resolve_rail_path(args.rail_path)

    if mode == "rail":
        args.rail_path = rail_auto
    elif mode == "synthetic":
        args.rail_path = None
    else:
        args.rail_path = rail_auto

    print(f"[mode] RUN_MODE={RUN_MODE} | rail_path={repr(args.rail_path)}")

    if args.rail_path:
        run_family(args)
        return

    rows = _run_family_synthetic(args)
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M")
    out = args.out or f"setcover_benchmark_pub_{ts}.csv"
    write_csv(rows, out)
    print("Wrote results →", out)
    print("MIP backend:", backend_name())

if __name__ == "__main__":
    main()
