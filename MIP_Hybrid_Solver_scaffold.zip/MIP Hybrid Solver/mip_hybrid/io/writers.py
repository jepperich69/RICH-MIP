
import os
import pandas as pd
from datetime import datetime

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def write_csv(df: pd.DataFrame, out_dir: str, stem: str) -> str:
    ensure_dir(out_dir)
    fp = os.path.join(out_dir, f"{stem}_{timestamp()}.csv")
    df.to_csv(fp, index=False)
    return fp

def latex_summary_table(df: pd.DataFrame, group_cols, metrics, caption: str, label: str) -> str:
    """Create a compact Overleaf-ready LaTeX \small table.
    df: long-form results; group_cols define rows; metrics is dict {col: aggfunc or list of aggfuncs}
    Returns LaTeX string.
    """
    if not isinstance(metrics, dict):
        raise ValueError("metrics must be a dict")
    agg = df.groupby(group_cols).agg(metrics)
    # Flatten multiindex columns
    agg.columns = ['{}_{}'.format(c[0], c[1]) if isinstance(c, tuple) else str(c) for c in agg.columns.values]
    agg = agg.reset_index()
    # Format numerics lightly
    for col in agg.columns:
        if agg[col].dtype.kind in "f":
            agg[col] = agg[col].map(lambda x: f"{x:.3g}")
    # Build LaTeX
    cols = agg.columns.tolist()
    colspec = "l" * len(cols)
    header = " & ".join(cols) + " \\"
    rows = [" & ".join(map(str, row)) + " \\" for row in agg.itertuples(index=False, name=None)]
    body = "\n".join(rows)
    tex = f"""\begin{{table}}[t]
\centering
\small
\caption{{{caption}}}
\label{{{label}}}
\begin{{tabular}}{{{colspec}}}
\toprule
{header}
\midrule
{body}
\bottomrule
\end{{tabular}}
\end{{table}}"""
    return tex

def write_latex(tex: str, out_dir: str, stem: str) -> str:
    ensure_dir(out_dir)
    fp = os.path.join(out_dir, f"{stem}_{timestamp()}.tex")
    with open(fp, "w", encoding="utf-8") as f:
        f.write(tex)
    return fp
