
import os
import argparse
import pandas as pd
from datetime import datetime

# Local package imports
from ..io.writers import write_csv, latex_summary_table, write_latex
from ..apps import rail_setcover as rail

def run_rail(rail_dir: str = None, synthetic_sizes=None, out_dir: str = "experiments/rail"):
    os.makedirs(out_dir, exist_ok=True)
    results = []

    # 1) RAIL 582 if available
    if rail_dir is not None:
        try:
            # Expect the app file to expose a helper load + run
            inst = rail.load_orlib_rail(rail_dir)  # function should exist in provided file
            res = rail.solve_instance(inst)        # wrapper: assumed present; if named differently, user can adapt
            res['family'] = 'RAIL582'
            results.append(res)
        except Exception as e:
            print("[warn] RAIL582 run skipped:", e)

    # 2) Synthetic sizes
    if synthetic_sizes:
        for (n, m, k, dens, seed) in synthetic_sizes:
            try:
                inst = rail.make_set_cover(n=n, m=m, k=k, density=dens, seed=seed)  # function should exist
                res = rail.solve_instance(inst)
                res.update({'family': 'SYN', 'n': n, 'm': m, 'k': k, 'density': dens, 'seed': seed})
                results.append(res)
            except Exception as e:
                print(f"[warn] synthetic ({n},{m},{k}) skipped:", e)

    if not results:
        print("[info] No results produced.")
        return None

    df = pd.DataFrame(results)
    csv_path = write_csv(df, out_dir, stem="rail_results")

    # LaTeX summary: median objective & times by family
    metrics = {
        'obj': 'median',
        'time_total': 'median' if 'time_total' in df.columns else 'mean',
    }
    group_cols = ['family']
    tex = latex_summary_table(df, group_cols, metrics, caption="RAIL/Synthetic summary (median).",
                              label="tab:rail_summary")
    tex_path = write_latex(tex, out_dir, stem="rail_summary_table")
    return {'csv': csv_path, 'tex': tex_path}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--rail_dir", type=str, default=None, help="Path to OR-Library RAIL582 directory")
    p.add_argument("--out_dir", type=str, default="experiments/rail", help="Output directory")
    p.add_argument("--syn", type=str, default="", help="Comma-separated synthetic tuples n:m:k:density:seed;...")
    args = p.parse_args()

    synthetic = []
    if args.syn:
        for token in args.syn.split(","):
            n, m, k, dens, seed = token.split(":")
            synthetic.append((int(n), int(m), int(k), float(dens), int(seed)))

    run_rail(args.rail_dir, synthetic, args.out_dir)

if __name__ == "__main__":
    main()
