
# MIP Hybrid Solver

This folder is structured as a single package with two applications (RAIL set cover; population/transport),
each with its own runner. Drop this entire folder into:

```
C:\Users\rich\OneDrive - Danmarks Tekniske Universitet\JR\Publikationer\MIP hybrid\MIP Hybrid Solver
```

## Layout
```
MIP Hybrid Solver/
  mip_hybrid/
    core/                 # shared (placeholder; integrate when ready)
    apps/
      rail_setcover.py    # from SETCOVER_RAIL_application_generator_FINAL_PORT.py
      population_transport.py  # from apps_population_transport.py
    runners/
      run_rail.py         # NEW: rail/synthetic runner + LaTeX
      run_apps.py         # your existing population/transport runner (as-is)
    io/
      writers.py          # CSV + Overleaf table helpers
  configs/
  experiments/
  cli.py                  # optional umbrella CLI
```

## Running (RAIL)
```bash
# From this folder
python -m mip_hybrid.runners.run_rail --rail_dir "PATH_TO_RAIL582_DIR" --out_dir experiments/rail
# With synthetic sizes (n:m:k:density:seed;...)
python -m mip_hybrid.runners.run_rail --syn "582:55515:1:0.001:42,400:20000:1:0.002:7"
```

This creates a CSV of raw results and an Overleaf-ready LaTeX table under `experiments/rail/`.

## Running (Population/Transport)
Your legacy runner is preserved:
```bash
python -m mip_hybrid.runners.run_apps
```
or via the umbrella CLI:
```bash
python cli.py apps
```

## Notes
- `writers.py` provides `write_csv` and `latex_summary_table(...)` used by the RAIL runner to emit publication-ready tables.
- If `rail_setcover.py` exposes different function names for loading/running, edit `run_rail.py` lines that call `load_orlib_rail`, `make_set_cover`, and `solve_instance` accordingly.
- You can later move shared kernels into `mip_hybrid/core/` without changing runner commands.
